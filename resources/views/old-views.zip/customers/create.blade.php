@extends('dashboard') @section('title', 'اضافة') @section('content')
 
                <div class="panel panel-default">
  <div class="panel-heading">منصة وقاية - ادارة المستخدمين - تسجيل مستخدم </div>
  <div class="panel-body">
  <div class="text-center imguser">
      <img src="dist/img/images.jpg">
      <hr>
  </div>
<form class="form-horizontal">
  
<div class="form-group">
    <label for="inputEmail3" class="col-sm-3 control-label">اسم المستخدم</label>
    <div class="col-sm-8">
      <input type="text" class="form-control" id="inputEmail3" placeholder="ادخل اسم المستخدم ">
      <div class="regicon">
      <i class="fa fa-user"></i>
      </div>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-3 control-label"> البريد الألكتروني</label>
    <div class="col-sm-8">
      <input type="email" class="form-control" id="inputEmail3" placeholder="ادخل البريد الألكتروني">
      <div class="regicon">
      <i class="fa fa-envelope-o"></i>
      </div>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-3 control-label">كلمة السر</label>
    <div class="col-sm-8">
      <input type="assword" class="form-control" id="inputEmail3" placeholder="ادخل كلمة السر">
      <div class="regicon">
      <i class="fa fa-eye"></i>
      </div>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-3 col-sm-6">
      <button type="submit" class="btn btn-success">تسجيل <i class="fa fa-sign-in"></i></button>
    </div>
  </div>
</form>
         </div>
</div>
@endsection