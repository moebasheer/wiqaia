@extends('dashboard') @section('title', 'الطلبات') @section('content')

          <!-- Small boxes (Stat box) -->
          <div class="panel panel-default">
  <div class="panel-heading">منصة وقاية - قائمة الطلبات الواردة</div>
  <div class="panel-body">
         <table class="table table-bordered">
  <tr class="text-center act">
      <td>رقم الطلب</td>
      <td>الاسم</td>
      <td>التحكم</td>
  </tr>
   <tr>
      <td> 1</td>
      <td>ابوبكر</td>
      <td class="text-center">
      <button class="btn btn-primary btn-sm">عرض <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">عديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button>
      </td>
  </tr>
   <tr>
      <td>2 </td>
      <td>نزار</td>
      <td class="text-center">
      <button class="btn btn-primary btn-sm">عرض <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">عديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button></td>
  </tr>
   <tr>
      <td>3 </td>
      <td>السماني</td>
      <td class="text-center"><button class="btn btn-primary btn-sm">عرض <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">عديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button></td>
  </tr>
</table>
       <nav>
  <ul class="pagination">
    <li class="disabled">
      <span>
        <span aria-hidden="true">&laquo;</span>
      </span>
    </li>
    <li class="active">
      <span>1 <span class="sr-only">(current)</span></span>
    </li>
    <li>
      <span>2 <span class="sr-only">(current)</span></span>
    </li>
    <li>
      <span>3 <span class="sr-only">(current)</span></span>
    </li>
    <li>
      <span>4 <span class="sr-only">(current)</span></span>
    </li>
    <li class="disabled">
      <span>
        <span aria-hidden="true">&raquo;</span>
      </span>
    </li>
  </ul>
  <button class="btn btn-primary btn-sm pull-left">Total : 12</button>
</nav>
              </div>
            </div>
            
@endsection