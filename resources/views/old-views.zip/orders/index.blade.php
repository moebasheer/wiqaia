@extends('dashboard') @section('title', 'اضافة') @section('content')

          <!-- Small boxes (Stat box) -->
          <div class="panel panel-default">
  <div class="panel-heading">منصة وقاية - عرض جميع  الطلبات</div>
  <div class="panel-body">
         <table class="table table-bordered">
  <tr class="text-center act">
      <td>ID# </td>
      <td>الاسم رباعي</td>
      <td>رقم العربة</td>
      <td>الغرض</td>
      <td>خط السير</td>
      <td> تاريخ البداية</td>
      <td> تاريخ النهاية</td>
      <td>الحالة</td>
      <td>التحكم</td>
  </tr>
   <tr>
      <td>1</td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="text-center"> <button class="btn btn-info btn-sm">مفعل </button></td>
      <td class="text-center">
      <button class="btn btn-primary btn-sm">عرض <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">تعديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button>
      </td>
  </tr>
   <tr>
      <td>2 </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="text-center"> <button class="btn btn-info btn-sm">مفعل </button></td>
      <td class="text-center">
      <button class="btn btn-primary btn-sm">عرض <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">تعديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button></td>
  </tr>
   <tr>
      <td>3 </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="text-center"> <button class="btn btn-danger btn-sm">غير مفعل </button></td>
      <td class="text-center"><button class="btn btn-primary btn-sm">عرض <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">تعديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button></td>
  </tr>
     <tr>
      <td>4 </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="text-center"> <button class="btn btn-info btn-sm">مفعل </button></td>
      <td class="text-center"><button class="btn btn-primary btn-sm">عرض <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">تعديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button></td>
  </tr>
     <tr>
      <td>5 </td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="text-center"> <button class="btn btn-danger btn-sm">غير مفعل </button></td>
      <td class="text-center"><button class="btn btn-primary btn-sm">عرض <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">تعديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button></td>
  </tr>
</table>
       <nav>
  <ul class="pagination">
    <li class="disabled">
      <span>
        <span aria-hidden="true">&laquo;</span>
      </span>
    </li>
    <li class="active">
      <span>1 <span class="sr-only">(current)</span></span>
    </li>
    <li>
      <span>2 <span class="sr-only">(current)</span></span>
    </li>
    <li>
      <span>3 <span class="sr-only">(current)</span></span>
    </li>
    <li>
      <span>4 <span class="sr-only">(current)</span></span>
    </li>
    <li class="disabled">
      <span>
        <span aria-hidden="true">&raquo;</span>
      </span>
    </li>
  </ul>
</nav>
              </div>
            </div>
            
@endsection