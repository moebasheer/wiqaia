@extends('dashboard') @section('title', 'تصديق تصريح') @section('content')

        <div class="panel panel-default">
  <div class="panel-heading">منصة وقاية - تصديق تصريح</div>
  <div class="panel-body">
<form class="form-horizontal">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">الاسم</label>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="inputEmail3" placeholder="ادخل الاسم">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">رقم العربة</label>
    <div class="col-sm-6">
      <input type="number" class="form-control" id="inputPassword3" placeholder="ادخل رقم العربة">
    </div>
  </div>
    <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">الغرض</label>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="inputPassword3" placeholder="الغرض">
    </div>
  </div>
    <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">خط السير </label>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="inputPassword3" placeholder="خط السير">
    </div>
  </div>
    <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">تلريخ البداية</label>
    <div class="col-sm-6">
      <input type="date" class="form-control" id="inputPassword3">
    </div>
  </div>
    <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">تاريخ النهاية</label>
    <div class="col-sm-6">
      <input type="date" class="form-control" id="inputPassword3">
    </div>
  </div>
  <div class="form-group text-center">
    <div class="col-sm-offset-2 col-sm-6">
      <button type="submit" class="btn btn-success">قبول</button>
      <button type="submit" class="btn btn-danger">رفض</button>
    </div>
  </div>
</form>
         </div>
</div>
@endsection