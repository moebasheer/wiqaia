@extends('dashboard') @section('title', 'عرض') @section('content')

          <!-- Small boxes (Stat box) -->
          <div class="panel panel-default">
  <div class="panel-heading">منصة وقاية - عرض جميع المقالات </div>
  <div class="panel-body">
         <table class="table table-bordered">
  <tr class="text-center act">
      <td>ID# </td>
      <td>عنوان المقال</td>
      <td>محتوي المقال</td>
      <td>صورة خاصة بالمقال</td>
      <td>التحكم</td>
  </tr>
   <tr>
      <td>1</td>
      <td>كرونا</td>
      <td style="width: 30%">كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا... </td>
      <td class="text-center"><img src="dist/img/w.jpg" width="100" height="100"></td>
      <td class="text-center">
      <button class="btn btn-primary btn-sm">مشاهدة المقال <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">تعديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button>
      </td>
  </tr>
  <tr>
      <td>1</td>
      <td>كرونا</td>
      <td style="width: 30%">كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا... </td>
      <td class="text-center"><img src="dist/img/w.jpg" width="100" height="100"></td>
      <td class="text-center">
      <button class="btn btn-primary btn-sm">مشاهدة المقال <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">تعديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button>
      </td>
  </tr>
  <tr>
      <td>1</td>
      <td>كرونا</td>
      <td style="width: 30%">كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا... </td>
      <td class="text-center"><img src="dist/img/w.jpg" width="100" height="100"></td>
      <td class="text-center">
      <button class="btn btn-primary btn-sm">مشاهدة المقال <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">تعديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button>
      </td>
  </tr>
  <tr>
      <td>1</td>
      <td>كرونا</td>
      <td style="width: 30%">كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا كرونا... </td>
      <td class="text-center"><img src="dist/img/w.jpg" width="100" height="100"></td>
      <td class="text-center">
      <button class="btn btn-primary btn-sm">مشاهدة المقال <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">تعديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button>
      </td>
  </tr>
</table>
       <nav>
  <ul class="pagination">
    <li class="disabled">
      <span>
        <span aria-hidden="true">&laquo;</span>
      </span>
    </li>
    <li class="active">
      <span>1 <span class="sr-only">(current)</span></span>
    </li>
    <li>
      <span>2 <span class="sr-only">(current)</span></span>
    </li>
    <li>
      <span>3 <span class="sr-only">(current)</span></span>
    </li>
    <li>
      <span>4 <span class="sr-only">(current)</span></span>
    </li>
    <li class="disabled">
      <span>
        <span aria-hidden="true">&raquo;</span>
      </span>
    </li>
  </ul>
</nav>
              </div>
            </div>
            
 @endsection