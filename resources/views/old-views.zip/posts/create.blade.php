@extends('dashboard') @section('title', 'اضافة') @section('content')
        <div class="panel panel-default">
  <div class="panel-heading">منصة وقاية -  اضافة مقال</div>
  <div class="panel-body">
<form class="form-horizontal">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">عنوان المقال</label>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="inputEmail3" placeholder="ادخل عنوان المقال">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">محتوي المقال</label>
    <div class="col-sm-6">
      <textarea rows="10" cols="5" class="form-control"></textarea>
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">صورة تعبيرية للمقال</label>
    <div class="col-sm-6">
      <input type="file" class="form-control" id="inputEmail3">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-6">
      <button type="submit" class="btn btn-primary">اضافة المقال <i class="fa fa-send"></i></button>
    </div>
  </div>
</form>
         </div>
</div>
@endsection