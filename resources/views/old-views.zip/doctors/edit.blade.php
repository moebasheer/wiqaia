 @extends('dashboard') 
 @section('title', 'تعديل') @section('content')
 
        <!-- Main content -->
        <section class="content">
        <div class="panel panel-default">
  <div class="panel-heading">منصة وقاية - الكادر الطبي - تعديل دكتور </div>
  <div class="panel-body">
<form class="form-horizontal">
  
<div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">الاسم رباعي</label>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="inputEmail3" placeholder="ادخل الاسم رباعي">
    </div>
  </div>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">رقم التلفون </label>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="inputPassword3" placeholder="ادخل رقم التلفون">
      <div class="regicon">
      <i class="fa fa-phone"></i>
      </div>
    </div>
  </div>
   <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label"> الوظيفة </label>
    <div class="col-sm-6">
      <input type="text" class="form-control" id="inputPassword3" placeholder="ادخل المسمى الوظيفي">
      
    </div>
  </div>
    <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">المدينة</label>
    <div class="col-sm-6">
       <div class="row">
           <div class="col-sm-4 text-right">
           <select class="form-control">
           <option>.....</option>
           <option>الخرطوم</option>
           <option>بحري</option>
           <option>ام درمان</option>
       </select>
       </div>
       <div class="col-sm-8">
       <input type="text" class="form-control" id="inputPassword3" placeholder="الرجاء ادخال العنوان ..."></div>
       </div>
        </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-6">
      <button type="submit" class="btn btn-primary">تسجيل <i class="fa fa-sign-in"></i></button>
    </div>
  </div>
</form>
         </div>
</div>
        </section><!-- /.content -->
        
  @endsection