@extends('dashboard') @section('title', 'عرض') @section('content')
          <!-- Small boxes (Stat box) -->
          <div class="panel panel-default">
  <div class="panel-heading">منصة وقاية - عرض جميع الكوادر الطبية</div>
  <div class="panel-body">
         <table class="table table-bordered">
  <tr class="text-center act"> 
      <td>الاسم رباعي</td>
      <td>رقم التلفون</td>
      <td>الوظيفة</td>
      <td>المدينة</td>
      <td>العنوان</td>
      <td>التحكم</td>
  </tr>
   <tr> 
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td class="text-center">
      <button class="btn btn-primary btn-sm">عرض <i class="fa fa-eye"></i></button>
       <button class="btn btn-success btn-sm">تعديل <i class="fa fa-edit"></i></button>
        <button class="btn btn-danger btn-sm">حذف <i class="fa fa-trash"></i></button>
      </td>
  </tr> 
</table> 
              </div>
            </div>
@endsection